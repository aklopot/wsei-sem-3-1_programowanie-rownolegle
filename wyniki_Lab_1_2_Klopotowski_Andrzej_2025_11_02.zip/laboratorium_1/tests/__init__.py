"""Tests package for Laboratorium 1."""
