x = 10
while x != 20:
    # utworzenie wątku 1 operującego na x (dodaje do x jedynkę)
    # utworzenie wątku 1 operującego na x (odejmuje od x jedynkę)
    x *= 2
print("koniec")
